import 'package:calculator/buttons.dart';
import 'package:flutter/material.dart';

class hoomePage extends StatefulWidget {
  const hoomePage({Key? key}) : super(key: key);

  @override
  State<hoomePage> createState() => _hoomePageState();
}

class _hoomePageState extends State<hoomePage> {
  final List<String> buttons = [
    'C',
    'DEL',
    '%',
    '/',
    '9',
    '8',
    '7',
    '*',
    '6',
    '5',
    '4',
    '-',
    '3',
    '2',
    '1',
    '+',
    '3',
    '2',
    '1',
    '/',
    '0',
    '.',
    'ANS',
    '=',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.greenAccent,
      body: Column(
        children: [
          Expanded(child: Container()),
          Expanded(
              flex: 2,
              child: Container(
                  child: GridView.builder(
                      itemCount: buttons.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4),
                      itemBuilder: (context, index) {
                        if (index == 0) {
                          return button(
                              buttontext: buttons[index],
                              color: Colors.green,
                              textcolor: Colors.white);
                        } else if (index == 1) {
                          return button(
                              buttontext: buttons[index],
                              color: Colors.redAccent,
                              textcolor: Colors.white);
                        } else {
                          return button(
                              buttontext: buttons[index],
                              color: isOperator(buttons[index])
                                  ? Colors.black
                                  : Colors.blueAccent,
                              textcolor: Colors.white);
                        }
                      }))),
        ],
      ),
    );
  }

  bool isOperator(String x) {
    if (x == '%' || x == '/' || x == '*' || x == '-' || x == '+') {
      return true;
    }
    return false;
  }
}
